// import 'package:api_demo_task/clothes_ui/controller/clothes_controller.dart';
// import 'package:api_demo_task/utils/app_colors.dart';
// import 'package:api_demo_task/utils/app_string.dart';
// import 'package:api_demo_task/widget/common_text.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
// class ClothesDataScreen extends StatelessWidget {
//    ClothesDataScreen({super.key});
//
//   final ClothesDataController clothesDataController = Get.put(ClothesDataController());
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         title: Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             Icon(Icons.arrow_back_ios_new_outlined,color: Colors.black,),
//             Icon(Icons.search,size: 25,color: Colors.black,)
//           ],
//         ),
//       ),
//       body: Column(
//         children: [
//           Row(
//             children: [
//               CommonText(
//                 text: AppString.womenTop,
//                 color: AppColors.blackColor,
//                 fontSize: 38,
//                 fontWeight: FontWeight.w900,
//               ),
//             ],
//           ),
//           Expanded(
//             child: ListView.separated(
//               scrollDirection: Axis.horizontal,
//               itemCount: clothesDataController.clothesTypeList.length,
//               itemBuilder: (context, index) {
//                     return Container(
//                       height: 100,
//                       color: AppColors.blackColor,
//                       child: CommonText(text: clothesDataController.clothesTypeList[index],).paddingSymmetric(vertical: 10,horizontal: 10),
//                     );
//             }, separatorBuilder: (BuildContext context, int index) {
//                 return SizedBox(width: 10,);
//             },),
//           )
//         ],
//       ).paddingSymmetric(horizontal: 14,vertical: 12)
//     );
//   }
// }

import 'package:api_demo_task/clothes_ui/controller/clothes_controller.dart';
import 'package:api_demo_task/clothes_ui/widget/clothes_details_card.dart';
import 'package:api_demo_task/utils/app_colors.dart';
import 'package:api_demo_task/utils/app_string.dart';
import 'package:api_demo_task/utils/assets.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:api_demo_task/widget/common_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ProductDataScreen extends StatelessWidget {
  final ProductDataController productController = Get.put(ProductDataController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor:AppColors.lightGreyColor,
        appBar: AppBar(
          backgroundColor: AppColors.whiteColor,
          elevation: 5,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(
                Icons.arrow_back_ios_new_outlined,
                color: Colors.black,
              ),
              Icon(
                Icons.search,
                size: 25,
                color: Colors.black,
              )
            ],
          ),
          bottom: PreferredSize(
              preferredSize: Size.fromHeight(170),
              child: Column(
                children: [
                  Row(
                    children: [
                      CommonText(
                        text: AppString.womenTop,
                        color: AppColors.blackColor,
                        fontSize: 38,
                        fontWeight: FontWeight.w800,
                      ).paddingSymmetric(horizontal: 14, vertical: 16),
                    ],
                  ),
                  Container(
                    height: 45,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: productController.productTypeList.length,
                      itemBuilder: (context, index) {
                        return Container(
                            decoration: BoxDecoration(color: AppColors.blackColor, borderRadius: BorderRadius.circular(30)),
                            child: CommonText(
                              text: productController.productTypeList[index],
                              color: Colors.white,
                              fontSize: 18,
                            ).paddingSymmetric(horizontal: 16, vertical: 12));
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(
                          width: 10,
                        );
                      },
                    ),
                  ).paddingOnly(left: 12),
                  Container(
                    height: 40,
                    color: AppColors.iconColor.withOpacity(0.1),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            SvgPicture.asset(IconsAsset.filterICon,height: 14,).paddingOnly(right: 10),
                            CommonText(text: AppString.filters,fontSize: 17,color: AppColors.blackColor,),
                          ],
                        ),
                        Row(
                          children: [
                            SvgPicture.asset(IconsAsset.upDownIcon,height: 22,).paddingOnly(right: 10),
                            CommonText(text: AppString.filters,fontSize: 17,color: AppColors.blackColor,),
                          ],
                        ),
                        Row(
                          children: [
                            SvgPicture.asset(IconsAsset.viewIcon,height: 15,),
                          ],
                        ),



                      ],
                    ),
                  ).paddingSymmetric(horizontal: 14,vertical:18)
                ],
              )),
        ),
        body: Column(
          children: [
            Expanded(
              flex: 9,
              child: Obx(() {
                return ListView.builder(
                  itemCount: productController.products.length,
                  itemBuilder: (context, index) {
                    return ProductCard(
                      product: productController.products[index],
                      index: index,
                      onFavoritePressed: (index) {
                        productController.toggleFavorite(index);
                      },
                    );
                  },
                ).paddingSymmetric(horizontal: 14, vertical: 12);
              }),
            ),
          ],
        ));
  }
}
